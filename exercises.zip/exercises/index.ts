document.addEventListener('DOMContentLoaded', () => {
  const greeting = document.getElementById('user-name')
  if (greeting) {
    greeting.textContent = 'Brendan'
  }
})
