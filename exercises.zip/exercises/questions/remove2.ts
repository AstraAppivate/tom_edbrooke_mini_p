const deleteMe = document.getElementById('nope')!
deleteMe.remove()
const deleteMeToo = document.getElementById('also-nope')!
deleteMeToo.remove()
